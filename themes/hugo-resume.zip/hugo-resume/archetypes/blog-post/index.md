---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
draft: false
tags: []
featured: false
weight: 100
aliases: []
resources:
    - name: headshot
      title: Eddie Webbinaro
      src: assets/headsot.jpg
---
{{< floatimg "headshot" "350x350" "Eddie headhsot" "right" >}}

Welcome to sample post

- list
- of 
- things

Special image formattting to float in upper right