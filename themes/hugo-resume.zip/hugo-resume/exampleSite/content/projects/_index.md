---
title: "Projects"
sitemap:
  priority : 0.9
---
<!--

This page represents the landing page for "projects" section. It is also shown under the homepage header for "projects". It should be therefore relatively short and sweet.

IN the dfault theme, "projects" is divided among "Creations" you authored and "contributions" made to others projects.

-->
<p>This section contains projects <a href="/projects/creations">created</a> and <a href="/projects/contributions">contributed</a> to by Eddie.  Everything listed is an open source effort, the distinction is only my role as owner or contributor.</p>
